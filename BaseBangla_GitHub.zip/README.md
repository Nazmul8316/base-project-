# BaseBangla

A simple static landing page for a Bangla Base/Web3 learning community.

## Run locally
Open `index.html` in a browser.

## GitHub Pages
1. Create a new GitHub repository.
2. Upload `index.html`, `style.css`, and `README.md`.
3. Go to **Settings → Pages**.
4. Select the `main` branch and `/ (root)`.
5. Save and open the generated Pages URL.

## Important
This is an educational community template. It does not promise an airdrop, token allocation, profit, or investment return.

Official Base: https://base.org
